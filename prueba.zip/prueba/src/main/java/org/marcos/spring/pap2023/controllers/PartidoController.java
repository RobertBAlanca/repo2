package org.marcos.spring.pap2023.controllers;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.marcos.spring.pap2023.entities.Aficion;
import org.marcos.spring.pap2023.entities.Equipo;
import org.marcos.spring.pap2023.entities.Fase;
import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.entities.Partido;
import org.marcos.spring.pap2023.entities.Persona;
import org.marcos.spring.pap2023.exception.DangerException;
import org.marcos.spring.pap2023.helpers.PRG;
import org.marcos.spring.pap2023.services.AficionService;
import org.marcos.spring.pap2023.services.EquipoService;
import org.marcos.spring.pap2023.services.FaseService;
import org.marcos.spring.pap2023.services.PaisService;
import org.marcos.spring.pap2023.services.PartidoService;
import org.marcos.spring.pap2023.services.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/partido")
public class PartidoController {

	@Autowired
	private PartidoService partidoService;
	
	@Autowired
	private EquipoService equipoService;

	@Autowired
	private FaseService faseService;

	@GetMapping("c")
	public String cGet(ModelMap m) {
		m.put("partidos", partidoService.getPartidos());
		m.put("equipos", equipoService.getEquipos());
		m.put("fases", faseService.getFases());

		m.put("view", "partido/c");
		return "_t/frame";
	}

	@PostMapping("c")
	public String cPost(
			@RequestParam("fecha") LocalDate fecha,
			@RequestParam("gl") String gl,
			@RequestParam("gv") String gv,
			@RequestParam("local") Long local,
			@RequestParam("visitante") Long visitante,
			@RequestParam("fase") Long fase	
			) throws DangerException {
		try {
			
			partidoService.savePartido(fecha,gl,gv,local, visitante,fase);
		} catch (Exception e) {
			PRG.error(e.getMessage(), "/partido/r");
		}
		return "redirect:/partido/r";
	}

	@GetMapping("r")
	public String rGet(ModelMap m) {
		List<Partido> partidos = partidoService.getPartidos();
		m.put("partidos", partidos);
		m.put("view", "partido/r");
		return "_t/frame";
	}

	@GetMapping("u")
	public String uGet(@RequestParam("id") Long idPartido, ModelMap m) {
		Partido partido = partidoService.getPartidoById(idPartido);
		List<Equipo> equipos = equipoService.getEquipos();
		List<Fase> fases = faseService.getFases();

		m.put("partido", partido);
		m.put("equipos", equipos);
		m.put("fases", fases);
		m.put("view", "partido/u");

		return "_t/frame";
	}

	@PostMapping("u")
	public String uPost(
			@RequestParam("idPartido") Long idPartido,
			@RequestParam("fecha") LocalDate fecha,
			@RequestParam("gl") String gl,
			@RequestParam("gv") String gv,
			@RequestParam("local") Long local,
			@RequestParam("visitante") Long visitante,
			@RequestParam("fase") Long fase	
			) throws DangerException {
		String retorno = "redirect:/partido/r";
		try {
			partidoService.updatePartido(idPartido,fecha, gl, gv,local,visitante,fase);
		} catch (Exception e) {
			PRG.error(e.getMessage(), "/partido/r");
		}
		return retorno;
	}

	@PostMapping("d")
	public String d(@RequestParam("id") Long id) {
		partidoService.deletePartido(id);
		return "redirect:/partido/r";
	}

}

