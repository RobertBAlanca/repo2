package org.marcos.spring.pap2023.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.marcos.spring.pap2023.entities.Aficion;
import org.marcos.spring.pap2023.entities.Equipo;
import org.marcos.spring.pap2023.entities.Fase;
import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.entities.Partido;
import org.marcos.spring.pap2023.entities.Persona;
import org.marcos.spring.pap2023.repositories.AficionRepository;
import org.marcos.spring.pap2023.repositories.EquipoRepository;
import org.marcos.spring.pap2023.repositories.FaseRepository;
import org.marcos.spring.pap2023.repositories.PartidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PartidoService {
	
	@Autowired
	private PartidoRepository partidoRepository;
	@Autowired
	private FaseRepository faseRepository;
	@Autowired
	private EquipoRepository equipoRepository;

	public List<Partido> getPartidos() {
		return partidoRepository.findAll();
	}
	
	public Partido getPartidoById(Long id) {
		return partidoRepository.getById(id);
	}
	
public void savePartido(LocalDate fecha, String gl, String gv,Long local, Long visitante ,Long fase) throws Exception {
		
		// Gestión de atributos "regulares"
	Partido partido = new Partido(fecha,gl,gv);
		
		// Gestión de equipos
		Equipo equipoLocal = equipoRepository.getById(local);
		Equipo equipoVisitante = equipoRepository.getById(visitante);
	
		partido.setLocal(equipoLocal);	
		partido.setVisitante(equipoVisitante);	
		
		equipoLocal.getLocal().add(partido);
		equipoVisitante.getVisitante().add(partido);
		
		
		// Gestión de fases
		
			Fase fasePartido = faseRepository.getById(fase);
			partido.setFase(fasePartido);
			fasePartido.getPartidos().add(partido);
		
		
		try {
			partidoRepository.saveAndFlush(partido);
		} catch (Exception e) {
			throw new Exception("El/la partido " + partido + " ya existe");
		}
	}

public void updatePartido(Long idPartido,LocalDate fecha, String gl, String gv,Long local, Long visitnate, Long fase) throws Exception {
	Partido partido = partidoRepository.getById(idPartido);
	
	partido.setFecha(fecha);
	partido.setGl(gl);
	partido.setGv(gv);
	if ( partido.getLocal()== null || local != partido.getLocal().getId() )  {
		Equipo equipoNuevo = equipoRepository.getById(local);
		partido.setLocal(equipoNuevo);
	}
	
	if ( partido.getVisitante()== null || visitnate != partido.getVisitante().getId() )  {
		Equipo equipoNuevo = equipoRepository.getById(visitnate);
		partido.setVisitante(equipoNuevo);
	}
	if ( partido.getFase()== null) {
		Fase faseNuevo = faseRepository.getById(fase);
		partido.setFase(faseNuevo);
	}
	
	try {
		partidoRepository.saveAndFlush(partido);
	} catch (Exception e) {
		throw new Exception("El/la partido ya existe");
	}
}

	public void deletePartido(Long id) {
		Partido partido = partidoRepository.getById(id);
		partidoRepository.delete(partido);
	}

}
