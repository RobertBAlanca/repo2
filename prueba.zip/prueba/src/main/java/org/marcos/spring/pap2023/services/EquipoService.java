package org.marcos.spring.pap2023.services;

import java.util.List;

import org.marcos.spring.pap2023.entities.Equipo;
import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.repositories.EquipoRepository;
import org.marcos.spring.pap2023.repositories.PaisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EquipoService {
	
	@Autowired
	private EquipoRepository equipoRepository;
	
	public List<Equipo> getEquipos() {
		return equipoRepository.findAll();
	}
	
	public void saveEquipo(String nombre) throws Exception {
		Equipo equipo = new Equipo(nombre);
		try {
			equipoRepository.saveAndFlush(equipo);
		}
		catch (Exception e) {
			throw new Exception("El equipo "+nombre+" ya existe");
		}	}

	
	public Equipo getEquipoById(Long id) {
		return equipoRepository.getById(id);
	}

	public void updateEquipo(Long idEquipo, String nombre) throws Exception {
		Equipo equipo = equipoRepository.getById(idEquipo);
		equipo.setNombre(nombre);
		try {
			equipoRepository.saveAndFlush(equipo);
		}
		catch (Exception e) {
			throw new Exception("El equipo "+nombre+" ya existe");
		}
	}

	public void deleteEquipo(Long id) {
		Equipo equipo = equipoRepository.getById(id);
		equipoRepository.delete(equipo);
	}
}
