package org.marcos.spring.pap2023.exception;

public class DangerException extends Exception {
	private static final long serialVersionUID = -6816739143105348971L;

	public DangerException(String mensaje) {
		super(mensaje);
	}
}
