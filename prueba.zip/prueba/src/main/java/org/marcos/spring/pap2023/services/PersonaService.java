package org.marcos.spring.pap2023.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.marcos.spring.pap2023.entities.Aficion;
import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.entities.Persona;
import org.marcos.spring.pap2023.repositories.AficionRepository;
import org.marcos.spring.pap2023.repositories.PaisRepository;
import org.marcos.spring.pap2023.repositories.PersonaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonaService {

	@Autowired
	private PersonaRepository personaRepository;
	
	@Autowired
	private PaisRepository paisRepository;
	
	@Autowired
	private AficionRepository aficionRepository;

	public List<Persona> getPersonas() {
		return personaRepository.findAll();
	}

	public void savePersona(String nombre, Long idPaisNace, Long idPaisResidencia,Long[] idGustos, Long[] idOdios ) throws Exception {
		
		// Gestión de atributos "regulares"
		Persona persona = new Persona(nombre);
		
		// Gestión de países
		Pais paisNacimiento = paisRepository.getById(idPaisNace);
		Pais paisResidencia = paisRepository.getById(idPaisResidencia);
		
		persona.setNace(paisNacimiento);
		persona.setVive(paisResidencia);

		paisNacimiento.getNacidos().add(persona);
		paisResidencia.getResidentes().add(persona);
		
		// Gestión de aficiones
		for ( Long idGusto : idGustos) {
			Aficion aficionGustada = aficionRepository.getById(idGusto);
			persona.getGustos().add(aficionGustada);
			aficionGustada.getAficionados().add(persona);
		}
		
		for ( Long idOdio : idOdios) {
			Aficion aficionOdiada = aficionRepository.getById(idOdio);
			persona.getOdios().add(aficionOdiada);
			aficionOdiada.getHaters().add(persona);
		}
		
		try {
			personaRepository.saveAndFlush(persona);
		} catch (Exception e) {
			throw new Exception("El/la persona " + nombre + " ya existe");
		}
	}

	public Persona getPersonaById(Long id) {
		return personaRepository.getById(id);
	}

	public void updatePersona(Long idPersona, String nombre, Long idPaisNace, Long idPaisVive, Long[] idGustos) throws Exception {
		Persona persona = personaRepository.getById(idPersona);
		
		persona.setNombre(nombre);
		
		if ( persona.getNace()== null || idPaisNace != persona.getNace().getId() )  {
			Pais nuevoPaisDeNacimiento = paisRepository.getById(idPaisNace);
			persona.setNace(nuevoPaisDeNacimiento);
		}
		
		if ( persona.getVive() == null || idPaisVive != persona.getVive().getId() )  {
			Pais nuevoPaisDeResidencia = paisRepository.getById(idPaisVive);
			persona.setVive(nuevoPaisDeResidencia);
		}
		
		Collection<Aficion> nuevosGustos = new ArrayList<Aficion>();
		for ( Long idGusto : idGustos) {
			nuevosGustos.add(aficionRepository.getById(idGusto));
		}
		persona.setGustos(nuevosGustos);
		
		try {
			personaRepository.saveAndFlush(persona);
		} catch (Exception e) {
			throw new Exception("El/la persona " + nombre + " ya existe");
		}
	}

	public void deletePersona(Long id) {
		Persona persona = personaRepository.getById(id);
		personaRepository.delete(persona);
	}
}

