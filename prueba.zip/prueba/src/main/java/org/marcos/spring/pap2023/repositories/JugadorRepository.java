package org.marcos.spring.pap2023.repositories;

import org.marcos.spring.pap2023.entities.Jugador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JugadorRepository extends JpaRepository<Jugador, Long> {

}
