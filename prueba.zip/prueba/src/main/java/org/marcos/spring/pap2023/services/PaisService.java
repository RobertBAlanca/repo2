package org.marcos.spring.pap2023.services;

import java.util.List;

import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.repositories.PaisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaisService {
	
	@Autowired
	private PaisRepository paisRepository;
	
	public List<Pais> getPaises() {
		return paisRepository.findAll();
	}
	
	public void savePais(String nombre) throws Exception {
		Pais pais = new Pais(nombre);
		try {
			paisRepository.saveAndFlush(pais);
		}
		catch (Exception e) {
			throw new Exception("El país "+nombre+" ya existe");
		}	}

	public Pais getPaisById(Long id) {
		return paisRepository.getById(id);
	}

	public void updatePais(Long idPais, String nombre) throws Exception {
		Pais pais = paisRepository.getById(idPais);
		pais.setNombre(nombre);
		try {
			paisRepository.saveAndFlush(pais);
		}
		catch (Exception e) {
			throw new Exception("El país "+nombre+" ya existe");
		}
	}

	public void deletePais(Long id) {
		Pais pais = paisRepository.getById(id);
		paisRepository.delete(pais);
	}
}
