package org.marcos.spring.pap2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pap2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Pap2023Application.class, args);
	}

}
