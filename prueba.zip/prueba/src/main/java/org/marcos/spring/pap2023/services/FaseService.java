package org.marcos.spring.pap2023.services;

import java.util.List;

import org.marcos.spring.pap2023.entities.Aficion;
import org.marcos.spring.pap2023.entities.Fase;
import org.marcos.spring.pap2023.repositories.AficionRepository;
import org.marcos.spring.pap2023.repositories.FaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FaseService {
	
	@Autowired
	private FaseRepository faseRepository;
	
	public List<Fase> getFases() {
		return faseRepository.findAll();
	}
	
	public void saveFase(String nombre,String orden) throws Exception {
		Fase fase = new Fase(nombre,orden);
		if (nombre.equals("")) {
			throw new Exception("El nombre de la fase no puede ser vacío");
		}
		try {
			
			faseRepository.saveAndFlush(fase);
		}
		catch (Exception e) {
			throw new Exception("La fase "+nombre+" ya existe");
		}
	}

	public Fase getFaseById(Long id) {
		return faseRepository.getById(id);
	}

	public void updateFase(Long idFase,String nombre,String orden) throws Exception {
		Fase fase = faseRepository.getById(idFase);
		fase.setNombre(nombre);
		fase.setOrden(orden);
		try {
			faseRepository.saveAndFlush(fase);
		}
		catch (Exception e) {
			throw new Exception("La fase "+nombre+" ya existe");
		}
	}

	public void deleteFase(Long id) {
		Fase fase = faseRepository.getById(id);
		//if (!pais.getResidentes().isEmpty() || !pais.getNacidos().isEmpty()) {
        //if (3==4) {
          //  throw new Exception(
            //		fase.getNombre()+
              //      " tiene algún residente/nacido aún. Borra todos sus elementos antes de intentar borrar el país"
                //    );
        //}
        //for (Partido partido : part.getResidentes()) {
        	//partido.setVive(null);
        	//partidoRepository.saveAndFlush(partido);
        //}
        faseRepository.delete(fase);

	//}
}
	}


