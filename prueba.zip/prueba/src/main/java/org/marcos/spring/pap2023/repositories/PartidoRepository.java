package org.marcos.spring.pap2023.repositories;


import org.marcos.spring.pap2023.entities.Partido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PartidoRepository extends JpaRepository<Partido, Long>{
}
