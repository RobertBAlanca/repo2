package org.marcos.spring.pap2023.exception;

public class InfoException extends Exception {
	private static final long serialVersionUID = -6424354307051530713L;

	public InfoException(String mensaje) {
		super(mensaje);
	}
}
