package org.marcos.spring.pap2023.controllers;

import java.util.List;

import org.marcos.spring.pap2023.entities.Fase;
import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.exception.DangerException;
import org.marcos.spring.pap2023.helpers.PRG;
import org.marcos.spring.pap2023.services.FaseService;
import org.marcos.spring.pap2023.services.PaisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/fase")
public class FaseController {

	@Autowired
	private FaseService faseService;

	@GetMapping("c")
	public String cGet(ModelMap m) {
		m.put("view", "fase/c");
		return "_t/frame";
	}

	@PostMapping("c")
	public String cPost(@RequestParam("nombre") String nombre,
			@RequestParam("orden")String orden) throws DangerException {
		try {
			faseService.saveFase(nombre, orden);
		}
		catch (Exception e) {
			PRG.error(e.getMessage(),"/fase/r");
		}
		return "redirect:/fase/r";
	}

	@GetMapping("r")
	public String rGet(ModelMap m) {
		List<Fase> fases = faseService.getFases();
		m.put("fases", fases);
		m.put("view", "fase/r");
		return "_t/frame";
	}

	@GetMapping("u")
	public String uGet(@RequestParam("idFase") Long idFase, ModelMap m) {
		Fase fase = faseService.getFaseById(idFase);

		m.put("fase", fase);
		m.put("view", "fase/u");

		return "_t/frame";
	}

	@PostMapping("u")
	public String uPost(
			@RequestParam("idFase") Long idFase, 
			@RequestParam("nombre") String nombre,
			@RequestParam("orden") String orden) throws DangerException {
		String retorno = "redirect:/fase/r"; 
		try {
			faseService.updateFase(idFase, nombre, orden);
		} catch (Exception e) {
			PRG.error(e.getMessage(),"/fase/r");
		}
		return retorno;
	}

	@PostMapping("d")
	public String d(
			@RequestParam("idFase") Long id) throws DangerException {
		try {
			faseService.deleteFase(id);

		} catch (Exception e) {
			PRG.error(e.getMessage(),"redirect:/fase/r");
		}
		return "redirect:/fase/r";
	}

}
