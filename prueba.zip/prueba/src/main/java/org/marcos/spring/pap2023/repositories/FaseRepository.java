package org.marcos.spring.pap2023.repositories;

import org.marcos.spring.pap2023.entities.Fase;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FaseRepository extends JpaRepository<Fase, Long>{
}
