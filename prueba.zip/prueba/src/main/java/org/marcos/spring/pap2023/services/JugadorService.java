package org.marcos.spring.pap2023.services;


import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.marcos.spring.pap2023.entities.Equipo;
import org.marcos.spring.pap2023.entities.Jugador;
import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.repositories.EquipoRepository;
import org.marcos.spring.pap2023.repositories.JugadorRepository;
import org.marcos.spring.pap2023.repositories.PaisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JugadorService {

	@Autowired
	private JugadorRepository jugadorRepository;
	@Autowired
	private EquipoRepository equipoRepository;
	
	
	public List<Jugador> getJugadores() {
		return jugadorRepository.findAll();
	}
	public Boolean validaDorsal(String dorsal,Long equipo) {
		List <Jugador> jugadores= (List<Jugador>) equipoRepository.getById(equipo).getJugadores();
		
		/*	List <String> dorsales = new ArrayList<>();
		for (Jugador jugador : jugadores) {
			dorsales.add(jugador.getDorsal());
		}
		dorsales.contains(dorsal);*/
		return jugadores.stream().map(jugador->jugador.getDorsal()).collect(Collectors.toList()).contains(dorsal);

		
	}

	public void saveJugador(String nombre,String apellido,String dorsal,Long equipo) throws Exception{
		 Boolean bo  =validaDorsal(dorsal,equipo);
			Equipo equipoJugador = equipoRepository.getById(equipo);
			Jugador jugador = new Jugador(nombre,apellido,dorsal);

		 if(!bo) {
			// Gestión de atributos "regulares"
				// Gestión de equipos
				jugador.setEquipo(equipoJugador);
				equipoJugador.getJugadores().add(jugador);
				try {
					jugadorRepository.saveAndFlush(jugador);
				} catch (Exception e) {
					throw new Exception("El/la jugador " + nombre + " ya existe");
				}
		 }else {
			 throw new Exception("El/la dorsal " + dorsal + " ya existe en el equipo "+equipoJugador.getNombre());
		 }
		
	
	}

	public Jugador getJugadorById(Long id) {
		return jugadorRepository.getById(id);
	}

	public void updateJugador(Long idJugador, String nombre, String apellido, String dorsal,Long equipo) throws Exception {
		Jugador jugador = jugadorRepository.getById(idJugador);
		jugador.setNombre(nombre);
		jugador.setApellido(apellido);
		jugador.setDorsal(dorsal);
		if ( jugador.getEquipo()== null || equipo != jugador.getEquipo().getId() )  {
			Equipo equipoActualizado = equipoRepository.getById(equipo);
			jugador.setEquipo(equipoActualizado);
		}
	
			jugadorRepository.saveAndFlush(jugador);
		
	}

	public void deleteJugador(Long id) {
		Jugador jugador = jugadorRepository.getById(id);
		jugadorRepository.delete(jugador);
	}
}

