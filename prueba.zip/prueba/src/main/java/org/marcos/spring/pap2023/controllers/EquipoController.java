package org.marcos.spring.pap2023.controllers;

import java.util.List;

import org.marcos.spring.pap2023.entities.Equipo;
import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.exception.DangerException;
import org.marcos.spring.pap2023.helpers.PRG;
import org.marcos.spring.pap2023.services.EquipoService;
import org.marcos.spring.pap2023.services.JugadorService;
import org.marcos.spring.pap2023.services.PaisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/equipo")
public class EquipoController {

	@Autowired
	private EquipoService equipoService;
	
	@Autowired
	private JugadorService jugadorService;

	@GetMapping("c")
	public String cGet(ModelMap m) {
		m.put("view", "equipo/c");
		return "_t/frame";
	}

	@PostMapping("c")
	public String cPost(@RequestParam("nombre") String nombre) throws DangerException {
		try {
			equipoService.saveEquipo(nombre);
		}
		catch (Exception e) {
			PRG.error(e.getMessage(),"/equipo/r");
		}
		return "redirect:/equipo/r";
	}

	@GetMapping("r")
	public String rGet(ModelMap m) {
		List<Equipo> equipos = equipoService.getEquipos();
		m.put("equipos", equipos);

		m.put("view", "equipo/r");
		return "_t/frame";
	}

	@GetMapping("u")
	public String uGet(@RequestParam("id") Long idEquipo, ModelMap m) {
		Equipo equipo = equipoService.getEquipoById(idEquipo);

		m.put("equipo", equipo);
		m.put("view", "equipo/u");

		return "_t/frame";
	}

	@PostMapping("u")
	public String uPost(@RequestParam("idEquipo") Long idEquipo, @RequestParam("nombre") String nombre) throws DangerException {
		String retorno = "redirect:/equipo/r"; 
		try {
			equipoService.updateEquipo(idEquipo, nombre);
		} catch (Exception e) {
			PRG.error(e.getMessage(),"/equipo/r");
		}
		return retorno;
	}

	@PostMapping("d")
	public String d(
			@RequestParam("id") Long id
			) throws DangerException {
		try {
			equipoService.deleteEquipo(id);
		} catch (Exception e) {
			PRG.error(e.getMessage(),"/equipo/r");
		}
		
		return "redirect:/equipo/r";
	}

}
