package org.marcos.spring.pap2023.entities;

import java.util.ArrayList;
import java.util.Collection;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Equipo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(unique = true)
	private String nombre;
	@OneToMany(mappedBy = "equipo")
	private Collection<Jugador> jugadores;
	@OneToMany(mappedBy = "local")
	private Collection<Partido> local;
	@OneToMany(mappedBy = "visitante")
	private Collection<Partido> visitante;
	
	public Equipo(String nombre) {
		super();
		this.nombre = nombre;
		this.jugadores = new ArrayList<Jugador>();	
		this.local= new ArrayList<Partido>();
		this.visitante= new ArrayList<Partido>();

	}
	
	public Equipo() {
		
		this.jugadores = new ArrayList<Jugador>();	
		this.local= new ArrayList<Partido>();
		this.visitante= new ArrayList<Partido>();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	

	public Collection<Jugador> getJugadores() {
		return jugadores;
	}

	public void setJugadores(Collection<Jugador> jugadores) {
		this.jugadores = jugadores;
	}

	public Collection<Partido> getLocal() {
		return local;
	}

	public void setLocal(Collection<Partido> local) {
		this.local = local;
	}

	public Collection<Partido> getVisitante() {
		return visitante;
	}

	public void setVisitante(Collection<Partido> visitante) {
		this.visitante = visitante;
	}


	
	}



	

