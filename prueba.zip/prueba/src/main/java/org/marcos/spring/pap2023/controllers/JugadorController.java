package org.marcos.spring.pap2023.controllers;

import java.util.List;

import org.marcos.spring.pap2023.entities.Aficion;
import org.marcos.spring.pap2023.entities.Equipo;
import org.marcos.spring.pap2023.entities.Jugador;
import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.entities.Persona;
import org.marcos.spring.pap2023.exception.DangerException;
import org.marcos.spring.pap2023.helpers.PRG;
import org.marcos.spring.pap2023.services.AficionService;
import org.marcos.spring.pap2023.services.EquipoService;
import org.marcos.spring.pap2023.services.JugadorService;
import org.marcos.spring.pap2023.services.PaisService;
import org.marcos.spring.pap2023.services.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/jugador")
public class JugadorController {

	@Autowired
	private JugadorService jugadorService;
	
	@Autowired
	private EquipoService equipoService;
	@GetMapping("c")
	public String cGet(ModelMap m) {
		m.put("equipos", equipoService.getEquipos());
		m.put("view", "jugador/c");
		return "_t/frame";
	}

	@PostMapping("c")
	public String cPost(
			@RequestParam("nombre") String nombre,
			@RequestParam("apellido") String apellido,
			@RequestParam("dorsal") String dorsal,
			@RequestParam("equipo") Long equipo

			) throws Exception {
		try {
			jugadorService.saveJugador(nombre, apellido,dorsal, equipo);

		} catch (Exception e) {
			PRG.error(e.getMessage(), "/jugador/r");
		}

		return "redirect:/jugador/r";
	}

	@GetMapping("r")
	public String rGet(ModelMap m) {
		List<Jugador> jugadores = jugadorService.getJugadores();
		m.put("jugadores", jugadores);

		m.put("view", "jugador/r");
		return "_t/frame";
	}

	@GetMapping("u")
	public String uGet(@RequestParam("id") Long idJugador, ModelMap m) {
		Jugador jugador = jugadorService.getJugadorById(idJugador);
		List<Equipo> equipos = equipoService.getEquipos();
		m.put("jugador", jugador);
		m.put("equipos", equipos);
		m.put("view", "jugador/u");

		return "_t/frame";
	}

	@PostMapping("u")
	public String uPost(
			@RequestParam("idJugador") Long idJugador,
			@RequestParam("nombre") String nombre,
			@RequestParam("apellido") String apellido,
			@RequestParam("dorsal") String dorsal,
			@RequestParam("equipo") Long equipo) throws DangerException{
			String retorno = "redirect:/jugador/r";
		try {
			jugadorService.updateJugador(idJugador, nombre, apellido, dorsal,equipo);
		} catch (Exception e) {
			PRG.error(e.getMessage(), "/jugador/r");
		}
		return retorno;
	}

	@PostMapping("d")
	public String d(@RequestParam("id") Long id) {
		jugadorService.deleteJugador(id);
		return "redirect:/jugador/r";
	}

}

