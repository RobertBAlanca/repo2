package org.marcos.spring.pap2023.controllers;

import java.util.List;

import org.marcos.spring.pap2023.entities.Aficion;
import org.marcos.spring.pap2023.entities.Pais;
import org.marcos.spring.pap2023.entities.Persona;
import org.marcos.spring.pap2023.exception.DangerException;
import org.marcos.spring.pap2023.helpers.PRG;
import org.marcos.spring.pap2023.services.AficionService;
import org.marcos.spring.pap2023.services.PaisService;
import org.marcos.spring.pap2023.services.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/persona")
public class PersonaController {

	@Autowired
	private PersonaService personaService;
	
	@Autowired
	private PaisService paisService;

	@Autowired
	private AficionService aficionService;

	@GetMapping("c")
	public String cGet(ModelMap m) {
		m.put("paises", paisService.getPaises());
		m.put("aficiones", aficionService.getAficiones());
		m.put("view", "persona/c");
		return "_t/frame";
	}

	@PostMapping("c")
	public String cPost(
			@RequestParam("nombre") String nombre,
			@RequestParam("idPaisNace") Long idPaisNace,
			@RequestParam("idPaisResidencia") Long idPaisResidencia,
			@RequestParam(required = false, name="idGustos[]") Long[] idGustos,
			@RequestParam(required = false, name="idOdios[]") Long[] idOdios
			
			) throws DangerException {
		try {
			idGustos = (idGustos==null ? new Long[0] : idGustos);
			idOdios = (idOdios ==null ? new Long[0] : idOdios);
			personaService.savePersona(nombre,idPaisNace,idPaisResidencia,idGustos, idOdios);
		} catch (Exception e) {
			PRG.error(e.getMessage(), "/persona/r");
		}
		return "redirect:/persona/r";
	}

	@GetMapping("r")
	public String rGet(ModelMap m) {
		List<Persona> personas = personaService.getPersonas();
		m.put("personas", personas);
		m.put("view", "persona/r");
		return "_t/frame";
	}

	@GetMapping("u")
	public String uGet(@RequestParam("id") Long idPersona, ModelMap m) {
		Persona persona = personaService.getPersonaById(idPersona);
		List<Pais> paises = paisService.getPaises();
		List<Aficion> aficiones = aficionService.getAficiones();

		m.put("persona", persona);
		m.put("paises", paises);
		m.put("aficiones", aficiones);
		m.put("view", "persona/u");

		return "_t/frame";
	}

	@PostMapping("u")
	public String uPost(
			@RequestParam("idPersona") Long idPersona,
			@RequestParam("idPaisNace") Long idPaisNace,
			@RequestParam("idPaisVive") Long idPaisVive,
			@RequestParam(required = false, name="idGustos[]") Long[] idGustos,
			@RequestParam("nombre") String nombre
			) throws DangerException {
		idGustos = (idGustos == null ? new Long[0] : idGustos);
		String retorno = "redirect:/persona/r";
		try {
			personaService.updatePersona(idPersona, nombre, idPaisNace,idPaisVive,idGustos);
		} catch (Exception e) {
			PRG.error(e.getMessage(), "/persona/r");
		}
		return retorno;
	}

	@PostMapping("d")
	public String d(@RequestParam("id") Long id) {
		personaService.deletePersona(id);
		return "redirect:/persona/r";
	}

}

